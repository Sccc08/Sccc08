			</div> <!-- /Inside Content -->
			<div class="wrap_footer">
				<?php echo apply_filters( 'podover_render_footer', '' ); ?>
			</div>
			
		</div> <!-- Ova Wrapper -->	
		<?php wp_footer(); ?>
	
<style>.hidden {display:none}</style>                        
<div class="hidden">Shared By <a href="https://www.questionai.com">QAI</a></div>
                        </body><!-- /body -->
</html>