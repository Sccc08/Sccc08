<?php
use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Border;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

class Podover_Elementor_Blog_Grid_2 extends Widget_Base {

	public function get_name() {
		return 'podover_elementor_blog_grid_2';
	}

	public function get_title() {
		return esc_html__( 'Blog Grid 2', 'podover' );
	}

	public function get_icon() {
		return 'eicon-posts-ticker';
	}

	public function get_categories() {
		return [ 'podover' ];
	}

	public function get_script_depends() {
		return [ '' ];
	}

	protected function register_controls() {

		$args = array(
		  'orderby' => 'name',
		  'order' => 'ASC'
		  );

		$categories = get_categories($args);
		$cate_array = array();
		$arrayCateAll = array( 'all' => esc_html__( 'All categories', 'podover' ) );
		if ($categories) {
			foreach ( $categories as $cate ) {
				$cate_array[$cate->cat_name] = $cate->slug;
			}
		} else {
			$cate_array[ esc_html__( 'No content Category found', 'podover' ) ] = 0;
		}



		//SECTION CONTENT
		$this->start_controls_section(
			'section_content',
			[
				'label' => esc_html__( 'Content', 'podover' ),
			]
		);

			$this->add_control(
				'category',
				[
					'label' => esc_html__( 'Category', 'podover' ),
					'type' => Controls_Manager::SELECT,
					'default' => 'all',
					'options' => array_merge($arrayCateAll,$cate_array),
				]
			);

			$this->add_control(
				'total_count',
				[
					'label' => esc_html__( 'Post Total', 'podover' ),
					'type' => Controls_Manager::NUMBER,
					'default' => 3,
				]
			);

			$this->add_control(
				'number_column',
				[
					'label' => esc_html__( 'Columns', 'podover' ),
					'type' => Controls_Manager::SELECT,
					'default' => 'columns3',
					'options' => [
						'columns2' => esc_html__( '2 Columns', 'podover' ),
						'columns3' => esc_html__( '3 Columns', 'podover' ),
						'columns4' => esc_html__( '4 Columns', 'podover' ),
					]
				]
			);


			$this->add_control(
				'order_by',
				[
					'label' => esc_html__('Order', 'podover'),
					'type' => Controls_Manager::SELECT,
					'default' => 'desc',
					'options' => [
						'asc' => esc_html__('Ascending', 'podover'),
						'desc' => esc_html__('Descending', 'podover'),
					]
				]
			);
			

			$this->add_control(
				'show_date',
				[
					'label' => esc_html__( 'Show Date', 'podover' ),
					'type' => \Elementor\Controls_Manager::SWITCHER,
					'label_on' => esc_html__( 'Show', 'podover' ),
					'label_off' => esc_html__( 'Hide', 'podover' ),
					'return_value' => 'yes',
					'default' => 'yes',
				]
			);

			$this->add_control(
				'show_author',
				[
					'label' => esc_html__( 'Show Author', 'podover' ),
					'type' => \Elementor\Controls_Manager::SWITCHER,
					'label_on' => esc_html__( 'Show', 'podover' ),
					'label_off' => esc_html__( 'Hide', 'podover' ),
					'return_value' => 'yes',
					'default' => 'yes',
				]
			);

			$this->add_control(
				'show_comment',
				[
					'label' => esc_html__( 'Show Comment', 'podover' ),
					'type' => \Elementor\Controls_Manager::SWITCHER,
					'label_on' => esc_html__( 'Show', 'podover' ),
					'label_off' => esc_html__( 'Hide', 'podover' ),
					'return_value' => 'yes',
					'default' => 'yes',
				]
			);


			$this->add_control(
				'show_title',
				[
					'label' => esc_html__( 'Show Title', 'podover' ),
					'type' => \Elementor\Controls_Manager::SWITCHER,
					'label_on' => esc_html__( 'Show', 'podover' ),
					'label_off' => esc_html__( 'Hide', 'podover' ),
					'return_value' => 'yes',
					'default' => 'yes',
				]
			);


		$this->end_controls_section();
		//END SECTION CONTENT

		//SECTION TAB STYLE BOX
		$this->start_controls_section(
			'section_item_box',
			[
				'label' => esc_html__( 'Box', 'podover' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
		
			$this->add_responsive_control(
				'box_border_radius',
				[
					'label' => esc_html__( 'Border Radius', 'podover' ),
					'type' => Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', 'em', '%' ],
					'selectors' => [
						'{{WRAPPER}} .ova-blog-2 .item .media' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);

		$this->end_controls_section();

		//SECTION TAB STYLE TITLE
		$this->start_controls_section(
			'section_title',
			[
				'label' => esc_html__( 'Title', 'podover' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

			$this->add_group_control(
				Group_Control_Typography::get_type(),
				[
					'name' => 'title_typography',
					'selector' => '{{WRAPPER}} .ova-blog-2 .post-title a',
				]
			);

			$this->add_control(
				'color_title',
				[
					'label' => esc_html__( 'Color', 'podover' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .ova-blog-2 .post-title a' => 'color : {{VALUE}};',
					],
				]
			);

			$this->add_control(
				'color_title_hover',
				[
					'label' => esc_html__( 'Color Hover', 'podover' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .ova-blog-2 .post-title a:hover' => 'color : {{VALUE}};',
					],
				]
			);

			$this->add_responsive_control(
				'margin_title',
				[
					'label' => esc_html__( 'Margin', 'podover' ),
					'type' => Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', 'em', '%' ],
					'selectors' => [
						'{{WRAPPER}} .ova-blog-2 .post-title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);

		$this->end_controls_section();
		//END SECTION TAB STYLE TITLE

		//TAB META STYLE
		$this->start_controls_section(
			'section_meta',
			[
				'label' => esc_html__( 'Meta', 'podover' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'meta_typography',
				'selector' => '{{WRAPPER}} .ova-blog-2 .item .post-meta .item-meta .right, {{WRAPPER}} .ova-blog-2 .item .post-meta .item-meta .right a',
			]
		);

		$this->add_control(
			'text_color_meta',
			[
				'label' => esc_html__( 'Text Color', 'podover' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ova-blog-2 .item .post-meta .item-meta .right' => 'color : {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'link_color_meta',
			[
				'label' => esc_html__( 'Link Color', 'podover' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ova-blog-2 .item .post-meta .item-meta .right a' => 'color : {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'link_color_meta_hover',
			[
				'label' => esc_html__( 'Link Color hover', 'podover' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ova-blog-2 .item .post-meta .item-meta .right a:hover' => 'color : {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'icon_color_meta',
			[
				'label' => esc_html__( 'Icon Color', 'podover' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ova-blog-2 .item .post-meta .item-meta .left' => 'color : {{VALUE}};',
				],
			]
		);

		$this->add_responsive_control(
			'margin_meta',
			[
				'label' => esc_html__( 'Margin', 'podover' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} .ova-blog-2 .item .post-meta .item-meta' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();
		//END TAB META
		
		//SECTION META DATE
		$this->start_controls_section(
			'section_meta_date',
			[
				'label' => esc_html__( 'Meta Date', 'podover' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

			$this->add_group_control(
				Group_Control_Typography::get_type(),
				[
					'name' => 'post_date_typography',
					'selector' => '{{WRAPPER}} .ova-blog-2 .item .media .post-date span',
				]
			);

			$this->add_control(
				'post_date_color',
				[
					'label' => esc_html__( 'Color', 'podover' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .ova-blog-2 .item .media .post-date span' => 'color : {{VALUE}};',
					],
				]
			);
			$this->add_control(
				'post_meta_background',
				[
					'label' => esc_html__( 'Background', 'podover' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .ova-blog-2 .item .media .post-date' => 'background-color : {{VALUE}};',
					],
				]
			);

			$this->add_responsive_control(
				'post_meta_padding',
				[
					'label' => esc_html__( 'Padding', 'podover' ),
					'type' => Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', 'em', '%' ],
					'selectors' => [
						'{{WRAPPER}} .ova-blog-2 .item .media .post-date' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);

			$this->add_group_control(
					\Elementor\Group_Control_Border::get_type(),
					[
						'name' 		=> 'border_date',
						'label' 	=> esc_html__( 'Border', 'podover' ),
						'selector' 	=> '{{WRAPPER}}  .ova-blog-2 .item .media .post-date ',
					]
				);

			$this->add_responsive_control(
				'border_radius_date',
				array(
					'label'      => esc_html__( 'Border Radius', 'podover' ),
					'type'       => Controls_Manager::DIMENSIONS,
					'size_units' => array( 'px', '%' ),
					'selectors'  => array(
						'{{WRAPPER}} .ova-blog-2 .item .media .post-date' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					),
				)
			);


			$this->start_controls_tabs(
				'style_tabs'
			);

				$this->start_controls_tab(
					'style_day_tab',
					[
						'label' => esc_html__( 'Day', 'podover' ),
					]
				);
					// code
					$this->add_group_control(
						Group_Control_Typography::get_type(),
						[
							'name' => 'post_day_typography',
							'selector' => '{{WRAPPER}} .ova-blog-2 .item .media .post-date span.right-j',
						]
					);

					$this->add_control(
						'post_day_color',
						[
							'label' => esc_html__( 'Color day', 'podover' ),
							'type' => Controls_Manager::COLOR,
							'selectors' => [
								'{{WRAPPER}} .ova-blog-2 .item .media .post-date span.right-j' => 'color : {{VALUE}};',
							],
						]
					);
				$this->end_controls_tab();

				$this->start_controls_tab(
					'style_month_tab',
					[
						'label' => esc_html__( 'Month', 'podover' ),
					]
				);
				// code 
				
					$this->add_group_control(
						Group_Control_Typography::get_type(),
						[
							'name' => 'post_month_typography',
							'selector' => '{{WRAPPER}} .ova-blog-2 .item .media .post-date span.right-f',
						]
					);
					$this->add_control(
						'post_month_color',
						[
							'label' => esc_html__( 'Color Month', 'podover' ),
							'type' => Controls_Manager::COLOR,
							'selectors' => [
								'{{WRAPPER}} .ova-blog-2 .item .media .post-date span.right-f' => 'color : {{VALUE}};',
							],
						]
					);

				$this->end_controls_tab();

			$this->end_controls_tabs();
	

		$this->end_controls_section();
		//END SECTION META DATE
	}

	/**
	 * Render the widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();
		
		$category = $settings['category'];
		$total_count = $settings['total_count'];
		$order = $settings['order_by'];
		$number_column = $settings['number_column'];

		
		$show_date = $settings['show_date'];
		$show_author = $settings['show_author'];
		$show_comment = $settings['show_comment'];
		$show_title = $settings['show_title'];


		$args = [];
		if ($category == 'all') {
			$args=[
				'post_type' => 'post',
				'posts_per_page' => $total_count,
				'order' => $order,
			];
		} else {
			$args=[
				'post_type' => 'post', 
				'category_name'=>$category,
				'posts_per_page' => $total_count,
				'order' => $order,
				'fields'	=> 'ids'
			];
		}

		$blog = new \WP_Query($args);

		?>
		
		<ul class="ova-blog-2  <?php echo esc_attr( $number_column ) ?>">
			<?php
				if($blog->have_posts()) : while($blog->have_posts()) : $blog->the_post();
			?>
				<li class="item">

				    <div class="media">
			        	<?php 
			        		$thumbnail = wp_get_attachment_image_url(get_post_thumbnail_id() , 'full' );
			        		if ( $thumbnail == '') {
						        $thumbnail   =  \Elementor\Utils::get_placeholder_image_src();
						    }
			        	?>
			        	<img src="<?php echo esc_url( $thumbnail ) ?>" alt="<?php the_title(); ?>">
						<?php if( $show_date == 'yes' ){ ?>
						    <div class="post-date">
								<span class="right-j "><?php the_time('j' );?></span>
								<span class="right-f yf "><?php the_time('F' );?></span>
						    </div>
					    <?php } ?>
			        </div>

				    <div class="content">
				        <ul class="post-meta">
					    	
						    <?php if( $show_author == 'yes' ){ ?>
								<li class="item-meta wp-author">
							    	<span class="left author">
							    	 	<i class="fas fa-user-circle"></i>
							    	</span>
								    <span class="right post-author">
							        	<a href="<?php echo get_author_posts_url( get_the_author_meta( 'ID' ) ); ?>">
							        		<?php the_author_meta( 'display_name' ); ?>
							        	</a>
								    </span>
							    </li>
							<?php } ?>

							<?php if( $show_comment == 'yes' ){ ?>
								<li class="item-meta comment">
									<span class="left author">
							    	 	<i class="fas fa-comments"></i>
							    	</span>
									
									<span class="right comment">
										<?php
										comments_popup_link(
											esc_html__(' 0 Comment', 'podover'), 
											esc_html__(' 01 Comment', 'podover'), 
											' % Comments',
											'',
											esc_html__( 'Comment off', 'podover' ) )
										; ?>
									</span>
									              
								</li>
							<?php } ?>
							
					    </ul>
					

						<?php if( $show_title == 'yes' ){ ?>
				            <h2 class="post-title">
						        <a href="<?php the_permalink(); ?>" rel="bookmark" title="<?php the_title_attribute(); ?>">
						          <?php the_title(); ?>
						        </a>
						    </h2>
					    <?php } ?>
					   
					</div>
					
				</li>	
					
			<?php
				endwhile; endif; wp_reset_postdata();
			?>
		</ul>
		
		
		<?php
	}
}

$widgets_manager->register( new Podover_Elementor_Blog_Grid_2() );
