<?php

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use \Elementor\Group_Control_Typography;
use Elementor\Utils;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly


class Podover_Elementor_Heading extends Widget_Base {

	
	public function get_name() {
		return 'podover_elementor_heading';
	}

	
	public function get_title() {
		return esc_html__( 'Heading', 'podover' );
	}

	
	public function get_icon() {
		return 'eicon-heading';
	}

	
	public function get_categories() {
		return [ 'podover' ];
	}

	public function get_script_depends() {
		return [ '' ];
	}
	
	// Add Your Controll In This Function
	protected function register_controls() {

		$this->start_controls_section(
			'section_content',
			[
				'label' => esc_html__( 'Content', 'podover' ),
			]
		);	
			
			
		$this->add_control(
			'sub_title',
			[
				'label' 	=> esc_html__( 'Sub Title', 'podover' ),
				'type' 		=> Controls_Manager::TEXT,
				'default' 	=> 'Sub title'
			]
		);

		$this->add_control(
			'title',
			[
				'label' 	=> esc_html__( 'Title', 'podover' ),
				'type' 		=> Controls_Manager::TEXTAREA,
				'default' 	=> 'Title'
			]
		);

		$this->add_control(
			'description',
			[
				'label' 	=> esc_html__( 'Description', 'podover' ),
				'type' 		=> Controls_Manager::TEXTAREA,
				'default' 	=> ''
			]
		);

		$this->add_control(
			'link_address',
			[
				'label'   		=> esc_html__( 'Link', 'podover' ),
				'type'    		=> \Elementor\Controls_Manager::URL,
				'show_external' => false,
				'default' 		=> [
					'url' 			=> '',
					'is_external' 	=> false,
					'nofollow' 		=> false,
				],
			]
		);

		$this->add_control(
			'apply_link_for_sub_title',
			[
				'label'   => esc_html__( 'Apply this link for sub title', 'podover' ),
				'type'    => Controls_Manager::SWITCHER,
				'default' => 'no',
				'options' => [
					'yes' => esc_html__( 'Yes', 'podover' ),
					'no'  => esc_html__( 'No', 'podover' ),
				],
			]
		);
		
		$this->add_control(
			'html_tag',
			[
				'label' 	=> esc_html__( 'HTML Tag', 'podover' ),
				'type' 		=> \Elementor\Controls_Manager::SELECT,
				'default' 	=> 'h2',
				'options' 	=> [
					'h1' 		=> esc_html__( 'H1', 'podover' ),
					'h2'  		=> esc_html__( 'H2', 'podover' ),
					'h3'  		=> esc_html__( 'H3', 'podover' ),
					'h4' 		=> esc_html__( 'H4', 'podover' ),
					'h5' 		=> esc_html__( 'H5', 'podover' ),
					'h6' 		=> esc_html__( 'H6', 'podover' ),
					'div' 		=> esc_html__( 'Div', 'podover' ),
					'span' 		=> esc_html__( 'span', 'podover' ),
					'p' 		=> esc_html__( 'p', 'podover' ),
				],
			]
		);

		$this->add_responsive_control(
			'align_heading',
			[
				'label' 	=> esc_html__( 'Alignment', 'podover' ),
				'type' 		=> \Elementor\Controls_Manager::CHOOSE,
				'options' 	=> [
					'left' => [
						'title' => esc_html__( 'Left', 'podover' ),
						'icon' 	=> 'eicon-text-align-left',
					],
					'center' => [
						'title' => esc_html__( 'Center', 'podover' ),
						'icon' 	=> 'eicon-text-align-center',
					],
					'right' => [
						'title' => esc_html__( 'Right', 'podover' ),
						'icon' 	=> 'eicon-text-align-right',
					],
				],
				'default' 	=> 'center',
				'toggle' 	=> true,
				'selectors' => [
					'{{WRAPPER}} .ova-title' => 'text-align: {{VALUE}}',
				],
			]
		);

		$this->end_controls_section();

		//SECTION TAB STYLE TITLE
		$this->start_controls_section(
			'section_title_style',
			[
				'label' => esc_html__( 'Title', 'podover' ),
				'tab' 	=> Controls_Manager::TAB_STYLE,
			]
		);
			$this->add_group_control(
				\Elementor\Group_Control_Typography::get_type(),
				[
					'name' 		=> 'content_typography_title',
					'label' 	=> esc_html__( 'Typography', 'podover' ),
					'selector' 	=> '{{WRAPPER}} .ova-title .title',
				]
			);

			$this->add_control(
				'color_title',
				[
					'label' 	=> esc_html__( 'Color', 'podover' ),
					'type' 		=> Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .ova-title .title' => 'color : {{VALUE}};',
						'{{WRAPPER}} .ova-title .title a' => 'color : {{VALUE}};',	
					],
				]
			);

			$this->add_control(
				'color_title_hover',
				[
					'label' 	=> esc_html__( 'Color hover', 'podover' ),
					'type' 		=> Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .ova-title .title a:hover' => 'color : {{VALUE}};'
					],
				]
			);

			$this->add_responsive_control(
				'padding_title',
				[
					'label' 	 => esc_html__( 'Padding', 'podover' ),
					'type' 		 => Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', 'em', '%' ],
					'selectors'  => [
						'{{WRAPPER}} .ova-title .title ' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);

			$this->add_responsive_control(
				'margin_title',
				[
					'label' 	 => esc_html__( 'Margin', 'podover' ),
					'type' 		 => Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', 'em', '%' ],
					'selectors'  => [
						'{{WRAPPER}} .ova-title .title ' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);

		$this->end_controls_section();
		//END SECTION TAB STYLE TITLE

		//SECTION TAB STYLE SUB TITLE
		$this->start_controls_section(
			'section_sub_title',
			[
				'label' => esc_html__( 'Sub Title', 'podover' ),
				'tab' 	=> Controls_Manager::TAB_STYLE,
			]
		);

			$this->add_control(
				'show_sub_title_underline',
				[
					'label'   => esc_html__( 'Show Underline', 'podover' ),
					'type'    => Controls_Manager::SWITCHER,
					'default' => 'no',
					'options' => [
						'yes' => esc_html__( 'Yes', 'podover' ),
						'no'  => esc_html__( 'No', 'podover' ),
					],
				]
			);

			$this->add_group_control(
				\Elementor\Group_Control_Typography::get_type(),
				[
					'name' 		=> 'content_typography_sub_title',
					'label' 	=> esc_html__( 'Typography', 'podover' ),
					'selector' 	=> '{{WRAPPER}} .ova-title h3.sub-title',
				]
			);

			$this->add_control(
				'color_sub_title',
				[
					'label'	 	=> esc_html__( 'Color', 'podover' ),
					'type' 		=> Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .ova-title h3.sub-title' => 'color : {{VALUE}};'
					],
				]
			);

			$this->add_responsive_control(
				'padding_sub_title',
				[
					'label' 	 => esc_html__( 'Padding', 'podover' ),
					'type' 		 => Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', 'em', '%' ],
					'selectors'  => [
						'{{WRAPPER}} .ova-title h3.sub-title ' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);

			$this->add_responsive_control(
				'margin_sub_title',
				[
					'label' 	 => esc_html__( 'Margin', 'podover' ),
					'type' 		 => Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', 'em', '%' ],
					'selectors'  => [
						'{{WRAPPER}} .ova-title h3.sub-title ' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);
			
		$this->end_controls_section();
		//END SECTION TAB STYLE SUB TITLE

		/* Begin Underlined Style */
		$this->start_controls_section(
			'section_underlined_style',
			[
				'label' 	=> esc_html__( 'Underline', 'podover' ),
				'tab' 		=> Controls_Manager::TAB_STYLE,
				'condition' => [
					'show_sub_title_underline' => 'yes'
				]
			]
		);

			$this->add_control(
				'underlined_background',
				[
					'label' 	=> esc_html__( 'Background', 'podover' ),
					'type' 		=> Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .ova-title .sub-title.has-underline::before' => 'background-color: {{VALUE}}',
					],
				]
			);

			$this->add_responsive_control(
				'underlined_width',
				[
					'label' 		=> esc_html__( 'Width', 'podover' ),
					'type' 			=> Controls_Manager::SLIDER,
					'size_units' 	=> [ 'px', '%', 'vw' ],
					'range' => [
						'px' => [
							'min' => 0,
							'max' => 1000,
							'step' => 5,
						],
						'%' => [
							'min' => 0,
							'max' => 100,
						],
						'vw' => [
							'min' => 0,
							'max' => 100,
						],
					],
					'selectors' => [
						'{{WRAPPER}} .ova-title .sub-title.has-underline::before' => 'width: {{SIZE}}{{UNIT}};',
					],
				]
			);

			$this->add_responsive_control(
				'underlined_height',
				[
					'label' 		=> esc_html__( 'Height', 'podover' ),
					'type' 			=> Controls_Manager::SLIDER,
					'size_units' 	=> [ 'px', '%', 'vh' ],
					'range' => [
						'px' => [
							'min' => 0,
							'max' => 500,
							'step' => 5,
						],
						'%' => [
							'min' => 0,
							'max' => 100,
						],
						'vh' => [
							'min' => 0,
							'max' => 100,
						],
					],
					'selectors' => [
						'{{WRAPPER}} .ova-title .sub-title.has-underline::before' => 'height: {{SIZE}}{{UNIT}};',
					],
				]
			);

			$this->add_responsive_control(
				'underlined_left',
				[
					'label' 		=> esc_html__( 'Left', 'podover' ),
					'type' 			=> Controls_Manager::SLIDER,
					'size_units' 	=> [ 'px', '%' ],
					'range' => [
						'px' => [
							'min' => -500,
							'max' => 500,
							'step' => 5,
						],
						'%' => [
							'min' => -120,
							'max' => 120,
						],
					],
					'selectors' => [
						'{{WRAPPER}} .ova-title .sub-title.has-underline::before' => 'left: {{SIZE}}{{UNIT}};',
					],
				]
			);

			$this->add_responsive_control(
				'underlined_right',
				[
					'label' 		=> esc_html__( 'Right', 'podover' ),
					'type' 			=> Controls_Manager::SLIDER,
					'size_units' 	=> [ 'px', '%' ],
					'range' => [
						'px' => [
							'min' => -500,
							'max' => 500,
							'step' => 5,
						],
						'%' => [
							'min' => -120,
							'max' => 120,
						],
					],
					'selectors' => [
						'{{WRAPPER}} .ova-title .sub-title.has-underline::before' => 'right: {{SIZE}}{{UNIT}};',
					],
				]
			);

			$this->add_responsive_control(
				'underlined_bottom',
				[
					'label' 		=> esc_html__( 'Bottom', 'podover' ),
					'type' 			=> Controls_Manager::SLIDER,
					'size_units' 	=> [ 'px', '%' ],
					'range' => [
						'px' => [
							'min' => -500,
							'max' => 500,
							'step' => 5,
						],
						'%' => [
							'min' => -120,
							'max' => 120,
						],
					],
					'selectors' => [
						'{{WRAPPER}} .ova-title .sub-title.has-underline::before' => 'bottom: {{SIZE}}{{UNIT}};',
					],
				]
			);

		$this->end_controls_section();
		/* End Underlined Style */

		//SECTION TAB STYLE DESCRIPTION
		$this->start_controls_section(
			'section_description',
			[
				'label' => esc_html__( 'Description', 'podover' ),
				'tab' 	=> Controls_Manager::TAB_STYLE,
			]
		);

			$this->add_group_control(
				\Elementor\Group_Control_Typography::get_type(),
				[
					'name' 		=> 'content_typography_description',
					'label' 	=> esc_html__( 'Typography', 'podover' ),
					'selector' 	=> '{{WRAPPER}} .ova-title .description',
				]
			);

			$this->add_control(
				'color_description',
				[
					'label'	 	=> esc_html__( 'Color', 'podover' ),
					'type' 		=> Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .ova-title .description' => 'color : {{VALUE}};'		
					],
				]
			);

			$this->add_responsive_control(
				'padding_description',
				[
					'label' 	 => esc_html__( 'Padding', 'podover' ),
					'type' 		 => Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', 'em', '%' ],
					'selectors'  => [
						'{{WRAPPER}} .ova-title .description ' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);

			$this->add_responsive_control(
				'margin_description',
				[
					'label' 	 => esc_html__( 'Margin', 'podover' ),
					'type' 		 => Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', 'em', '%' ],
					'selectors'  => [
						'{{WRAPPER}} .ova-title .description ' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);
			
		$this->end_controls_section();
		//END SECTION TAB STYLE DESCRIPTION
		
	}

	// Render Template Here
	protected function render() {

		$settings = $this->get_settings();

		$title     		= $settings['title'];
		$sub_title 		= $settings['sub_title'];
		$description	= $settings['description']; 
		$link      		= $settings['link_address']['url'];
		$target    		= $settings['link_address']['is_external'] ? ' target="_blank"' : '';
		$html_tag  		= $settings['html_tag'];

		$apply_link_for_sub_title = $settings['apply_link_for_sub_title'];

		$show_sub_title_underline = $settings['show_sub_title_underline'];

		if( $show_sub_title_underline == 'yes' ) {
			$has_underline = 'has-underline';
		} else {
			$has_underline = '';
		}
		
		?>

			<div class="ova-title">

				<?php if($sub_title && ( $apply_link_for_sub_title == 'yes' ) ): ?>
					<a href="<?php echo esc_url( $link ); ?>"<?php printf( $target ); ?>>
						<h3 class="sub-title <?php echo esc_attr($has_underline);?>"><?php echo esc_html( $sub_title ); ?></h3>
					</a>
				<?php elseif( $sub_title ) : ?>
					<h3 class="sub-title <?php echo esc_attr($has_underline);?>">
						<?php echo esc_html( $sub_title ); ?>	
					</h3>
				<?php endif; ?>

				<?php if($title): ?>
					<?php if( $link ) { ?>
						<<?php echo esc_html($html_tag); ?> class="title"><a href="<?php echo esc_url( $link ); ?>"<?php printf( $target ); ?>><?php echo esc_html( $title ); ?></a></<?php echo esc_html($html_tag); ?>>
					<?php } else { ?>
							<<?php echo esc_html($html_tag); ?> class="title"><?php echo esc_html( $title ); ?></<?php echo esc_html($html_tag); ?>>
					<?php } ?>
				<?php endif; ?>

				<?php if($description): ?>
					<p class="description"><?php echo esc_html($description); ?></p>
				<?php endif; ?>

			</div> 
			
		<?php
	}

	
}
$widgets_manager->register( new Podover_Elementor_Heading() );