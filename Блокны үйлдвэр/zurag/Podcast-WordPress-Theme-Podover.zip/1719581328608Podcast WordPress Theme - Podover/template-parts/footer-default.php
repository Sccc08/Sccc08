<footer class="footer">
	<div class="row_site">
		<div class="container_site">
			<?php esc_html_e( 'Design and Develop by Ovatheme', 'podover' ); ?>
		</div>
	</div>
</footer>
