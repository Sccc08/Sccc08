<?php if(is_active_sidebar('woo-sidebar')){ ?>
        <aside id="woo-sidebar" class="sidebar woo-sidebar">
            <?php  dynamic_sidebar('woo-sidebar'); ?>
        </aside>
<?php } ?>