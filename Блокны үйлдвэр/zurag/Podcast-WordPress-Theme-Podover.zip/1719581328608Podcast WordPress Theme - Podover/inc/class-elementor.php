<?php

class Podover_Elementor {
	
	function __construct() {
            
		// Register Header Footer Category in Pane
	    add_action( 'elementor/elements/categories_registered', array( $this, 'podover_add_category' ) );

	    add_action( 'elementor/frontend/after_register_scripts', array( $this, 'podover_enqueue_scripts' ) );
		
		add_action( 'elementor/widgets/register', array( $this, 'podover_include_widgets' ) );
		
		add_filter( 'elementor/controls/animations/additional_animations', array( $this, 'podover_add_animations'), 10 , 0 );

		add_action( 'wp_print_footer_scripts', array( $this, 'podover_enqueue_footer_scripts' ) );

		// load icons
		add_filter( 'elementor/icons_manager/additional_tabs', array( $this, 'podover_icons_filters_new' ), 9999999, 1 );

		//Add Button custom control style 
		add_action( 'elementor/element/button/section_style/after_section_end', array( $this, 'podover_button_custom' ), 10, 2 );

		// Add Podover fonts
		add_filter( 'elementor/fonts/groups', array( $this, 'podover_font_groups' ), 9999999, 1 );
		add_filter( 'elementor/fonts/additional_fonts', array( $this, 'podover_additional_fonts' ), 9999999, 1 );

		// Add style Icon box		
		add_action( 'elementor/element/icon-box/section_style_content/after_section_end', array( $this,  'podover_icon_content_custom' ), 10, 2 );

		//Add icons social custom
		add_action( 'elementor/element/social-icons/section_social_hover/after_section_end', array( $this, 'podover_social_icons_custom' ), 10, 2 );

		//Add text editor custom control style
		add_action( 'elementor/element/text-editor/section_style/after_section_end', array( $this, 'podover_text_editor_custom' ), 10, 2 );
	}

	
	function podover_add_category(  ) {

	    \Elementor\Plugin::instance()->elements_manager->add_category(
	        'hf',
	        [
	            'title' => __( 'Header Footer', 'podover' ),
	            'icon' => 'fa fa-plug',
	        ]
	    );

	    \Elementor\Plugin::instance()->elements_manager->add_category(
	        'podover',
	        [
	            'title' => __( 'Podover', 'podover' ),
	            'icon' => 'fa fa-plug',
	        ]
	    );

	}

	function podover_enqueue_scripts(){
        
        $files = glob(get_theme_file_path('/assets/js/elementor/*.js'));
        
        foreach ($files as $file) {
            $file_name = wp_basename($file);
            $handle    = str_replace(".js", '', $file_name);
            $src       = get_theme_file_uri('/assets/js/elementor/' . $file_name);
            if (file_exists($file)) {
                wp_register_script( 'podover-elementor-' . $handle, $src, ['jquery'], false, true );
            }
        }


	}

	function podover_include_widgets( $widgets_manager ) {
        $files = glob(get_theme_file_path('elementor/widgets/*.php'));
        foreach ($files as $file) {
            $file = get_theme_file_path('elementor/widgets/' . wp_basename($file));
            if (file_exists($file)) {
                require_once $file;
            }
        }
    }

    function podover_add_animations(){
    	$animations = array(
            'Podover' => array(
                'ova-move-up' 		=> esc_html__('Move Up', 'podover'),
                'ova-move-down' 	=> esc_html__( 'Move Down', 'podover' ),
                'ova-move-left'     => esc_html__('Move Left', 'podover'),
                'ova-move-right'    => esc_html__('Move Right', 'podover'),
                'ova-scale-up'      => esc_html__('Scale Up', 'podover'),
                'ova-flip'          => esc_html__('Flip', 'podover'),
                'ova-helix'         => esc_html__('Helix', 'podover'),
                'ova-popup'			=> esc_html__( 'PopUp','podover' )
            ),
        );

        return $animations;
    }

   

	function podover_enqueue_footer_scripts(){
		// Font Icon
	    wp_enqueue_style('ovaicon', PODOVER_URI.'/assets/libs/ovaicon/font/ovaicon.css', array(), null);

	    // Flaticon
	    wp_enqueue_style('flaticon', PODOVER_URI.'/assets/libs/flaticon/font/flaticon.css', array(), null);
	}
	
	

	public function podover_icons_filters_new( $tabs = array() ) {

		$newicons = [];

		$font_data['json_url'] = PODOVER_URI.'/assets/libs/ovaicon/ovaicon.json';
		$font_data['name'] = 'ovaicon';
		$newicons[ $font_data['name'] ] = [
			'name'          => $font_data['name'],
			'label'         => esc_html__( 'Default', 'podover' ),
			'url'           => '',
			'enqueue'       => '',
			'prefix'        => 'ovaicon-',
			'displayPrefix' => '',
			'ver'           => '1.0',
			'fetchJson'     => $font_data['json_url'],
		];

		$font_flaticon['json_url'] = PODOVER_URI.'/assets/libs/flaticon/flaticon.json';
		$font_flaticon['name'] = 'flaticon';
		$newicons[ $font_flaticon['name'] ] = [
			'name'          => $font_flaticon['name'],
			'label'         => esc_html__( 'Flaticon', 'podover' ),
			'url'           => '',
			'enqueue'       => '',
			'prefix'        => 'flaticon-',
			'displayPrefix' => '',
			'ver'           => '1.0',
			'fetchJson'     => $font_flaticon['json_url'],
		];

		return array_merge( $tabs, $newicons );

	}
    
    function podover_button_custom( $element, $args ) {
		/** @var \Elementor\Element_Base $element */
		$element->start_controls_section(
			'ova_button',
			[
				'tab' 	=> \Elementor\Controls_Manager::TAB_STYLE,
				'label' => esc_html__( 'Ova Button', 'podover' ),
			]
		);

		    $element->add_responsive_control(
				'icon_size',
				[
					'label' 	=> esc_html__( 'Icon Size', 'podover' ),
					'type' 		=> \Elementor\Controls_Manager::SLIDER,
					'default' 	=> [
						'unit' 	=> 'px',
					],
					'tablet_default' => [
						'unit' => 'px',
					],
					'mobile_default' => [
						'unit' => 'px',
					],
					'range' => [
						'px' => [
							'min' => 0,
							'max' => 40,
						],
					],
					'size_units' 	=> [ 'px' ],
					'selectors' 	=> [
						'{{WRAPPER}} .elementor-button-icon  i' => 'font-size: {{SIZE}}{{UNIT}};',
						'{{WRAPPER}} .elementor-button-icon  svg' => 'font-size: {{SIZE}}{{UNIT}};',
					],
				]
			);		

			$element->add_control(
				'ova_icon_button_color',
				[
					'label' 	=> esc_html__( 'Color', 'podover' ),
					'type' 		=> \Elementor\Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .elementor-button .elementor-button-icon i' => 'color: {{VALUE}};',
					],
				]
			);


			$element->add_control(
				'ova_icon_button_bg',
				[
					'label' 	=> esc_html__( 'Background', 'podover' ),
					'type' 		=> \Elementor\Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .elementor-button .elementor-button-icon i' => 'background-color: {{VALUE}};',
					],
				]
			);

			$element->add_responsive_control(
				'ova_icon_button_padding',
				[
					'label' 		=> esc_html__( 'Padding', 'podover' ),
					'type' 			=>  \Elementor\Controls_Manager::DIMENSIONS,
					'size_units' 	=> [ 'px', 'em', '%' ],
					'selectors' 	=> [
						'{{WRAPPER}} .elementor-button .elementor-button-icon i' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}} ;',
					],
				]
			);

			$element->add_control(
				'border_radius_icon_button',
				array(
					'label'      => esc_html__( 'Border Radius', 'podover' ),
					'type'       =>  \Elementor\Controls_Manager::DIMENSIONS,
					'size_units' => array( 'px', '%' ),
					'selectors'  => array(
						'{{WRAPPER}} .elementor-button .elementor-button-icon i' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					),
				)
			);


			$element->add_responsive_control(
				'align_item_button',
				[
					'label' 	=> esc_html__( 'Alignment Item', 'podover' ),
					'type' 		=> \Elementor\Controls_Manager::CHOOSE,
					'options' 	=> [
						'flex-start' => [
							'title' => esc_html__( 'Flex Start', 'podover' ),
							'icon' 	=> 'eicon-v-align-top',
						],
						'center' => [
							'title' => esc_html__( 'Center', 'podover' ),
							'icon' 	=> 'eicon-v-align-middle',
						],
						'flex-end' => [
							'title' => esc_html__( 'Flex End', 'podover' ),
							'icon' 	=> 'eicon-v-align-bottom',
						],
					],
				
					'toggle' 	=> true,
					'selectors' => [
						'{{WRAPPER}} .elementor-button span' => 'align-items: {{VALUE}}',

					],
				]
			);



		$element->end_controls_section();

	}


	function podover_font_groups( $args = array() ) {

		$groups['podover'] = esc_html__( 'Podover', 'podover' );
		return array_merge( $args, $groups );
	}

	function podover_additional_fonts( $args = array() ) {

		$fonts['Reey'] 	= 'podover';

		return array_merge( $args, $fonts );
	}

	function podover_icon_content_custom ( $element, $args ) {
		/** @var \Elementor\Element_Base $element */
		$element->start_controls_section(
			'ova_content',
			[
				'tab' 	=> \Elementor\Controls_Manager::TAB_STYLE,
				'label' => esc_html__( 'Ova Content',  'podover' ),
			]
		);

			$element->add_responsive_control(
				'ova_title_icon_box_margin',
				[
					'label' 		=> esc_html__( 'Title Margin', 'podover' ),
					'type' 			=>  \Elementor\Controls_Manager::DIMENSIONS,
					'size_units' 	=> [ 'px', 'em', '%' ],
					'selectors' 	=> [
						'{{WRAPPER}} .elementor-icon-box-wrapper .elementor-icon-box-content .elementor-icon-box-title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}} ;',
					],
				]
			);


		$element->end_controls_section();
	}

	function podover_social_icons_custom ( $element, $args ) {
	/** @var \Elementor\Element_Base $element */
	$element->start_controls_section(
		'ova_social_icons',
		[
			'tab' 	=> \Elementor\Controls_Manager::TAB_STYLE,
			'label' => esc_html__( 'Ova Social Icon', 'podover' ),
		]
	);

		$element->add_responsive_control(
            'ova_social_icons_display',
            [
                'label' 	=> esc_html__( 'Display', 'podover' ),
                'type' 		=> \Elementor\Controls_Manager::CHOOSE,
                'options' 	=> [
                    'inline-block' => [
                        'title' => esc_html__( 'Block', 'podover' ),
                        'icon' 	=> 'eicon-h-align-left',
                    ],
                    'inline-flex' => [
                        'title' => esc_html__( 'Flex', 'podover' ),
                        'icon' 	=> 'eicon-h-align-center',
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .elementor-icon.elementor-social-icon' => 'display: {{VALUE}}',
                ],
            ]
        );

		$element->end_controls_section();
	}

	// Ova text-editor custom 
    function podover_text_editor_custom( $element, $args ) {
		/** @var \Elementor\Element_Base $element */
		$element->start_controls_section(
			'ova_tabs',
			[
				'tab' 	=> \Elementor\Controls_Manager::TAB_STYLE,
				'label' => esc_html__( 'Ova Text Editor', 'podover' ),
			]
		);

			$element->add_responsive_control(
				'text_margin',
				[
					'label' 		=> esc_html__( 'Margin', 'podover' ),
					'type' 			=> \Elementor\Controls_Manager::DIMENSIONS,
					'size_units' 	=> [ 'px', '%', 'em' ],
					'selectors' 	=> [
					'{{WRAPPER}}  p' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);

			$element->add_responsive_control(
		        'text_padding',
		        [
		            'label' 		=> esc_html__( 'Padding', 'podover' ),
		            'type' 			=> \Elementor\Controls_Manager::DIMENSIONS,
		            'size_units' 	=> [ 'px', '%', 'em' ],
		            'selectors' 	=> [
		             '{{WRAPPER}}  p' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
		            ],
		         ]
		    );

		$element->end_controls_section();
	}  


}

return new Podover_Elementor();